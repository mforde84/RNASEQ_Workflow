**********
Setting up
**********

.. toctree::
   :maxdepth: 1

   whatisnumpy
   install
