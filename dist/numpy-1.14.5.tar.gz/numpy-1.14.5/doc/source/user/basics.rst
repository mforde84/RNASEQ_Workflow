************
NumPy basics
************

.. toctree::
   :maxdepth: 1

   basics.types
   basics.creation
   basics.io
   basics.indexing
   basics.broadcasting
   basics.byteswapping
   basics.rec
   basics.subclassing
