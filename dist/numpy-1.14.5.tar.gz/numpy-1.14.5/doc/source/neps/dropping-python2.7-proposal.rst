.. include:: ../../neps/dropping-python2.7-proposal.rst
