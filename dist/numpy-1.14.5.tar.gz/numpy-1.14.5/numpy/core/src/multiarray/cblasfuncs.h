#ifndef _NPY_CBLASFUNCS_H_
#define _NPY_CBLASFUNCS_H_

NPY_NO_EXPORT PyObject *
cblas_matrixproduct(int, PyArrayObject *, PyArrayObject *, PyArrayObject *);

#endif
