#!/bin/bash

flake8 --exclude=.git tests/*.py setup.py
