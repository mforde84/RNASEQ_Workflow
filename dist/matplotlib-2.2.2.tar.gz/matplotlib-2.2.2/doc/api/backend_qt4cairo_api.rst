
:mod:`matplotlib.backends.backend_qt4cairo`
===========================================

.. automodule:: matplotlib.backends.backend_qt4cairo
   :members:
   :undoc-members:
   :show-inheritance:
