
:mod:`matplotlib.backends.backend_qt5agg`
=========================================

.. automodule:: matplotlib.backends.backend_qt5agg
   :members:
   :undoc-members:
   :show-inheritance:
