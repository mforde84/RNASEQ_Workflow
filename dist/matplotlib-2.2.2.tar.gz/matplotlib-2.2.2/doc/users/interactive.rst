.. _dump-index:

===================
 Interactive plots
===================

.. toctree::
    :maxdepth: 2

    navigation_toolbar.rst
    shell.rst
    event_handling.rst
