.. _mplot3d_example:

.. _mplot3d-examples-index:

3D plotting
===========
